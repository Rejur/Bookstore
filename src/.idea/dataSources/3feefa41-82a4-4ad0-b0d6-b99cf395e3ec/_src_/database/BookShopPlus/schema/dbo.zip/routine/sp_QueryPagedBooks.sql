CREATE PROC [dbo].[sp_QueryPagedBooks]
@SortField VARCHAR(20),--排序字段
@CategoryId INT,--分类编号
@PageSize INT,--页大小
@currPageIndex INT,--页号
@PageCount INT OUTPUT --页数
AS
--计算总页数
DECLARE @TotalCount int 
SELECT  @TotalCount=COUNT(0) FROM books WHERE CategoryId=@CategoryId
IF(@TotalCount%@PageSize<>0)
   SET @PageCount=@TotalCount/@PageSize+1
ELSE
   SET @PageCount=@TotalCount/@PageSize

IF(@SortField='PublishDate')
BEGIN
	SELECT  TOP(@PageSize) Id,ISBN, Title, Author, PublisherId, PublishDate, 
	UnitPrice,SUBSTRING(ContentDescription,0,200) AS ShortContent
	FROM books
	WHERE CategoryId=@CategoryId
    AND Id NOT IN(
	SELECT TOP(@PageSize*(@currPageIndex-1)) Id FROM books
	WHERE CategoryId=@CategoryId
	ORDER BY PublishDate
	)
	ORDER BY PublishDate
END
ELSE IF(@SortField='UnitPrice')
BEGIN
    SELECT  TOP(@PageSize) Id,ISBN, Title, Author, PublisherId, PublishDate, 
	UnitPrice,SUBSTRING(ContentDescription,0,200) AS ShortContent
	FROM books
	WHERE CategoryId=@CategoryId
    AND Id NOT IN(
	SELECT TOP(@PageSize*(@currPageIndex-1)) Id FROM books
	WHERE CategoryId=@CategoryId
	ORDER BY UnitPrice
	)
	ORDER BY UnitPrice
END
GO
