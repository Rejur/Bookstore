CREATE VIEW dbo.vw_Users
AS
SELECT     dbo.Users.Id, dbo.Users.LoginId, dbo.Users.LoginPwd, dbo.Users.Name, dbo.Users.Address, dbo.Users.Mail, dbo.Users.Phone, 
                      dbo.UserRoles.Name AS RoleName, dbo.UserStates.Name AS StateName
FROM         dbo.UserRoles INNER JOIN
                      dbo.Users ON dbo.UserRoles.Id = dbo.Users.UserRoleId INNER JOIN
                      dbo.UserStates ON dbo.Users.UserStateId = dbo.UserStates.Id
GO
